# Astulink — design brief

## Brand
Astulink is a French-language digital shop for practical spreadsheet templates and downloadable tools. The catalogue spans ten everyday and professional categories: budget & finance, home & organisation, pets & nature, sport & leisure, weddings & events, freelancers & craftspeople, property & rentals, family & children, transport & mobility, and associations & clubs.

## Positioning
Practical, clear, accessible, useful. The brand should feel like a well-organised French stationery and tools shop rather than a corporate SaaS dashboard. Keep language plain and welcoming; avoid promising that every catalogue item is already available.

## Visual direction
- Warm off-white paper background, sage green accents, dark forest typography, restrained peach details.
- Editorial French typography with serif display headlines and clean sans-serif UI text.
- Spacious layout, soft borders, subtle card elevation, simple line icons.
- CSS-only motion: gentle entrance, floating spreadsheet preview, animated bars, hover lift. Respect reduced-motion preferences.
- Responsive desktop and mobile layout.

## Commercial constraints
- No fixed monthly platform costs at launch.
- Payment and digital delivery integration is pending; do not show fake checkout buttons or imply purchases can already be completed.
- Clearly label sample product cards as in preparation until payment and fulfillment are connected.
