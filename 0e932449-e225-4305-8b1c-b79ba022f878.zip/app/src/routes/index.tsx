import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Calculator,
  CarFront,
  Check,
  ChevronDown,
  Dumbbell,
  FileSpreadsheet,
  Heart,
  Home,
  Menu,
  PawPrint,
  Search,
  ShieldCheck,
  Sparkles,
  Users,
  Wallet,
  X,
} from "lucide-react";

export const Route = createFileRoute("/")({ component: HomePage });

const categories = [
  { id: "budget", title: "Budget & finances", description: "Suivez vos dépenses, vos économies et vos projets.", icon: Wallet, count: "Budget, épargne, crédits" },
  { id: "maison", title: "Maison & organisation", description: "Gardez une maison organisée sans y passer des heures.", icon: Home, count: "Planning, inventaires, entretien" },
  { id: "animaux", title: "Animaux & nature", description: "Centralisez les petites tâches et le suivi du quotidien.", icon: PawPrint, count: "Animaux, jardin, aquarium" },
  { id: "sport", title: "Sport & loisirs", description: "Planifiez vos séances et mesurez vos progrès.", icon: Dumbbell, count: "Entraînement, sorties, loisirs" },
  { id: "evenements", title: "Mariage & événements", description: "Préparez vos événements avec une vue claire.", icon: Heart, count: "Invités, budget, organisation" },
  { id: "pro", title: "Indépendants & artisans", description: "Chiffrez, suivez et pilotez votre activité.", icon: Calculator, count: "Devis, prix, ventes, suivi" },
  { id: "immobilier", title: "Immobilier & location", description: "Organisez vos biens et vos locations.", icon: Home, count: "Locations, états, interventions" },
  { id: "famille", title: "Famille & enfants", description: "Simplifiez la gestion des activités familiales.", icon: Users, count: "Planning, dépenses, activités" },
  { id: "transport", title: "Transport & mobilité", description: "Suivez les frais et l'entretien de vos véhicules.", icon: CarFront, count: "Kilométrage, entretien, trajets" },
  { id: "associations", title: "Associations & clubs", description: "Centralisez les adhésions et la vie du club.", icon: Users, count: "Adhérents, cotisations, événements" },
];

const examples = [
  { name: "Carnet d'aquarium", category: "Animaux & nature", tag: "Animaux & nature", description: "Suivez vos tests d'eau et vos changements d'eau sans oublier les dates.", color: "mint", icon: PawPrint, price: "0,99 €" },
  { name: "Carnet de levain", category: "Maison & organisation", tag: "Maison & organisation", description: "Suivez les rafraîchis, la pousse et le comportement de votre levain.", color: "peach", icon: Home, price: "0,99 €" },
  { name: "Carnet d'arrosage des plantes", category: "Maison & organisation", tag: "Maison & organisation", description: "Un petit planning pour ne plus oublier vos plantes d'intérieur.", color: "lavender", icon: Home, price: "0,99 €" },
  { name: "Budget road trip & vanlife", category: "Transport & mobilité", tag: "Transport & mobilité", description: "Calculez le coût d'un voyage en van et suivez les dépenses au fil des étapes.", color: "mint", icon: CarFront, price: "0,99 €" },
  { name: "Carnet de suivi de votre animal", category: "Animaux & nature", tag: "Animaux & nature", description: "Centralisez promenades, toilettage, rendez-vous et petites notes de suivi.", color: "peach", icon: PawPrint, price: "0,99 €" },
  { name: "Suivi des invités de mariage", category: "Mariage & événements", tag: "Mariage & événements", description: "Centralisez réponses, repas et besoins pratiques de vos invités.", color: "lavender", icon: Heart, price: "0,99 €" },
  { name: "Carnet d'heures de babysitting", category: "Famille & enfants", tag: "Famille & enfants", description: "Suivez les gardes, horaires, frais et sommes à régler.", color: "mint", icon: Users, price: "0,99 €" },
  { name: "Carnet de kilomètres professionnel", category: "Transport & mobilité", tag: "Transport & mobilité", description: "Consignez vos trajets professionnels et calculez les distances parcourues.", color: "peach", icon: CarFront, price: "0,99 €" },
  { name: "Calculateur de prix pour créations artisanales", category: "Indépendants & artisans", tag: "Indépendants & artisans", description: "Fixez un prix en intégrant matières, temps, emballage et frais de vente.", color: "lavender", icon: Calculator, price: "0,99 €" },
  { name: "Carnet de ventes pour marché & stand", category: "Indépendants & artisans", tag: "Indépendants & artisans", description: "Suivez recettes, dépenses du stand et résultat de chaque journée.", color: "mint", icon: Calculator, price: "0,99 €" },
  { name: "Checklist ménage & rotation de location", category: "Immobilier & location", tag: "Immobilier & location", description: "Préparez chaque arrivée et départ avec une liste de contrôle réutilisable.", color: "peach", icon: Home, price: "0,99 €" },
  { name: "Carnet WOD & progression", category: "Sport & loisirs", tag: "Sport & loisirs", description: "Notez vos entraînements, scores, charges et ressentis.", color: "lavender", icon: Dumbbell, price: "0,99 €" },
  { name: "Carnet de pêche", category: "Sport & loisirs", tag: "Sport & loisirs", description: "Gardez une trace de vos sorties, conditions, spots et prises.", color: "mint", icon: Dumbbell, price: "0,99 €" },
  { name: "Inventaire du congélateur", category: "Maison & organisation", tag: "Maison & organisation", description: "Sachez ce qu'il vous reste, où le trouver et quand l'utiliser.", color: "peach", icon: Home, price: "0,99 €" },
  { name: "Inventaire de déménagement", category: "Maison & organisation", tag: "Maison & organisation", description: "Numérotez vos cartons et retrouvez facilement leur contenu.", color: "lavender", icon: Home, price: "0,99 €" },
  { name: "Suivi des devis & factures", category: "Indépendants & artisans", tag: "Indépendants & artisans", description: "Suivez les devis envoyés, factures émises et règlements attendus.", color: "mint", icon: Calculator, price: "0,99 €" },
  { name: "Calculateur de devis ménage", category: "Indépendants & artisans", tag: "Indépendants & artisans", description: "Estimez le prix d'une intervention selon surface, durée et options.", color: "peach", icon: Calculator, price: "0,99 €" },
  { name: "Stock buvette & petite restauration", category: "Associations & clubs", tag: "Associations & clubs", description: "Suivez achats, ventes et stock restant lors d'un événement.", color: "lavender", icon: Users, price: "0,99 €" },
  { name: "Calculateur de coût couture", category: "Indépendants & artisans", tag: "Indépendants & artisans", description: "Évaluez le coût d'une création textile et son prix de vente.", color: "mint", icon: Calculator, price: "0,99 €" },
  { name: "Inventaire de jeux de société", category: "Famille & enfants", tag: "Famille & enfants", description: "Suivez votre ludothèque, les prêts et les pièces manquantes.", color: "peach", icon: Users, price: "0,99 €" },
];

function Logo() {
  return (
    <a className="ast-brand" href="#accueil" aria-label="Astulink, accueil">
      <span className="ast-brand-mark"><FileSpreadsheet size={21} strokeWidth={2.2} /></span>
      <span>astu<span>link</span><i>®</i></span>
    </a>
  );
}

function HomePage() {
  const [activeCategory, setActiveCategory] = useState("Toutes");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [language, setLanguage] = useState("fr");
  const [productQuery, setProductQuery] = useState("");
  const [showAllProducts, setShowAllProducts] = useState(false);
  const copy = ({
    fr: { nav1:"Catégories", nav2:"Nos outils", nav3:"Comment ça marche", cta:"Explorer la boutique", eyebrow:"LA BOÎTE À OUTILS DU QUOTIDIEN", h1a:"Moins de casse-tête.", h1b:"Plus de choses", h1c:" bien faites.", lead:"Des fichiers Excel pratiques pour organiser vos projets, suivre vos chiffres et gagner du temps. Quel que soit votre quotidien, il y a un outil pour vous.", find:"Trouver mon outil", concept:"Découvrir le concept", categories:"Tout commence", cat2:"par la bonne catégorie.", tools:"Des outils qui font", tools2:"gagner du temps.", how:"Prêt à l’emploi.", how2:"Facile à prendre en main.", free:"Télécharger gratuitement" },
    en: { nav1:"Categories", nav2:"Our tools", nav3:"How it works", cta:"Explore the store", eyebrow:"YOUR EVERYDAY TOOLKIT", h1a:"Less hassle.", h1b:"More things", h1c:" done right.", lead:"Practical Excel files to organise projects, track numbers and save time. Whatever your day looks like, there is a tool for you.", find:"Find my tool", concept:"Discover the idea", categories:"It all starts", cat2:"with the right category.", tools:"Tools that help you", tools2:"save time.", how:"Ready to use.", how2:"Easy to get started.", free:"Download for free" },
    es: { nav1:"Categorías", nav2:"Nuestras herramientas", nav3:"Cómo funciona", cta:"Explorar la tienda", eyebrow:"TU CAJA DE HERRAMIENTAS", h1a:"Menos complicaciones.", h1b:"Más cosas", h1c:" bien hechas.", lead:"Archivos Excel prácticos para organizar proyectos, controlar cifras y ahorrar tiempo. Sea cual sea tu día a día, hay una herramienta para ti.", find:"Encuentra tu herramienta", concept:"Descubre el concepto", categories:"Todo empieza", cat2:"con la categoría adecuada.", tools:"Herramientas para", tools2:"ahorrar tiempo.", how:"Listo para usar.", how2:"Fácil de utilizar.", free:"Descargar gratis" }
  } as const)[language as "fr" | "en" | "es"];
  const visibleProducts = useMemo(() => examples.filter((product) => {
    const categoryMatch = activeCategory === "Toutes" || categories.find((category) => category.title === product.category)?.id === activeCategory;
    const searchText = `${product.name} ${product.category} ${product.description}`.toLowerCase();
    return categoryMatch && searchText.includes(productQuery.toLowerCase());
  }), [activeCategory, productQuery]);
  const displayedProducts = showAllProducts ? visibleProducts : visibleProducts.slice(0, 6);
  const selectedCategory = categories.find((category) => category.id === activeCategory)?.title;

  return (
    <main className="ast-site" id="accueil">
      <div className="ast-topline"><span>Des outils simples pour mieux s'organiser</span><span className="ast-topline-right"><ShieldCheck size={13} /> Fichiers numériques · Téléchargement</span></div>
      <header className="ast-header">
        <div className="ast-header-inner">
          <Logo />
          <nav className="ast-nav" aria-label="Navigation principale">
            <a href="#selection">{copy.nav2}</a>
            <a href="#fonctionnement">{copy.nav3}</a>
          </nav>
          <div className="ast-header-actions">
            <label className="ast-locale"><span className="sr-only">Language</span><select aria-label="Language" value={language} onChange={(e) => setLanguage(e.target.value)}><option value="fr">FR</option><option value="en">EN</option><option value="es">ES</option></select></label>
            <a className="ast-header-cta" href="#selection">{copy.cta} <ArrowUpRight size={16} /></a>
            <button className="ast-menu-toggle" aria-label={mobileOpen ? "Fermer le menu des catégories" : "Ouvrir le menu des catégories"} aria-expanded={mobileOpen} onClick={() => setMobileOpen(!mobileOpen)}><Menu size={22}/><span>Catégories</span></button>
          </div>
        </div>
      </header>
      {mobileOpen && <><button className="ast-drawer-backdrop" aria-label="Fermer le menu" onClick={() => setMobileOpen(false)} /><aside className="ast-category-drawer" aria-label="Toutes les catégories"><div className="ast-drawer-head"><div><span className="ast-eyebrow">PARCOURIR LA BOUTIQUE</span><h2>Les catégories</h2></div><button aria-label="Fermer" onClick={() => setMobileOpen(false)}><X size={21}/></button></div><button className="ast-drawer-all" onClick={() => { setActiveCategory("Toutes"); setShowAllProducts(false); setMobileOpen(false); document.getElementById("selection")?.scrollIntoView({behavior:"smooth"}); }}>Tous les produits <ArrowRight size={16}/></button><div className="ast-drawer-list">{categories.map((category) => { const Icon = category.icon; return <button key={category.id} className={activeCategory === category.id ? "ast-drawer-category active" : "ast-drawer-category"} onClick={() => { setActiveCategory(category.id); setShowAllProducts(true); setMobileOpen(false); document.getElementById("selection")?.scrollIntoView({behavior:"smooth"}); }}><span className="ast-drawer-icon"><Icon size={18}/></span><span><b>{category.title}</b><small>{category.count}</small></span><ArrowUpRight size={16}/></button>; })}</div></aside></>}

      <section className="ast-hero">
        <div className="ast-hero-grid" aria-hidden="true" />
        <div className="ast-hero-copy">
          <div className="ast-eyebrow"><span className="ast-eyebrow-dot" /> {copy.eyebrow}</div>
          <h1>{copy.h1a}<br /><em>{copy.h1b}</em>{copy.h1c}</h1>
          <p className="ast-hero-lead">{copy.lead}</p>
          <div className="ast-hero-actions">
            <a className="ast-button ast-button-dark" href="#selection">{copy.find} <ArrowRight size={17} /></a>
            <a className="ast-text-link" href="#fonctionnement">{copy.concept} <ArrowDown size={15} /></a>
          </div>
          <div className="ast-hero-proof"><span><Check size={14} /> Simples à utiliser</span><span><Check size={14} /> Pensés pour le quotidien</span><span><Check size={14} /> Sans abonnement</span></div>
        </div>
        <div className="ast-hero-art" aria-label="Aperçu illustré d'un tableau de suivi">
          <div className="ast-orbit ast-orbit-one" /><div className="ast-orbit ast-orbit-two" />
          <div className="ast-float ast-float-a"><span className="ast-float-icon mint"><Wallet size={17}/></span><span><b>Budget maîtrisé</b><small>Tout au même endroit</small></span><span className="ast-check"><Check size={13}/></span></div>
          <div className="ast-sheet">
            <div className="ast-sheet-head"><div><span className="ast-sheet-kicker">VOTRE ESPACE</span><b>Tableau de bord</b></div><span className="ast-sheet-dots">•••</span></div>
            <div className="ast-sheet-metrics"><div><small>Budget restant</small><strong>1 240 €</strong><span className="ast-positive">+12,8 % ce mois</span></div><div className="ast-mini-chart"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></div>
            <div className="ast-sheet-line"><span>Répartition des dépenses</span><b>68 %</b></div>
            <div className="ast-progress"><i /></div>
            <div className="ast-sheet-rows"><span><i className="dot dot-green"/> Logement</span><b>620 €</b><span><i className="dot dot-orange"/> Courses</span><b>245 €</b><span><i className="dot dot-blue"/> Loisirs</span><b>130 €</b></div>
            <div className="ast-sheet-footer"><span><span className="ast-live-dot"/> Données à jour</span><span>Vue mensuelle ↗</span></div>
          </div>
          <div className="ast-float ast-float-b"><span className="ast-float-icon peach"><Sparkles size={17}/></span><span><b>Simple, vraiment.</b><small>Vous remplissez, ça calcule.</small></span></div>
          <div className="ast-sticker">L'utile<br/>en mieux<span>✳</span></div>
        </div>
        <div className="ast-hero-bottom"><span>DES OUTILS POUR TOUS VOS PROJETS</span><span>01 — 10 CATÉGORIES</span></div>
      </section>

      <section className="ast-selection" id="selection">
        <div className="ast-selection-head"><div><div className="ast-eyebrow">LE CATALOGUE ASTULINK</div><h2>{selectedCategory ? <>{selectedCategory}<br/><em>nos outils associés.</em></> : <>Les best-sellers<br/><em>à découvrir.</em></>}</h2></div><div className="ast-selection-note">Sélection éditoriale de lancement : aucun classement basé sur des ventes pour le moment. Les aperçus sont des maquettes ; les fichiers seront finalisés avant leur mise en vente.</div></div>
        <div className="ast-catalogue-tools"><label className="ast-product-search"><Search size={19}/><input value={productQuery} onChange={(e) => {setProductQuery(e.target.value);setShowAllProducts(true);}} placeholder="Rechercher un outil : budget, animaux, devis…" aria-label="Rechercher un fichier Excel"/>{productQuery && <button aria-label="Effacer la recherche" onClick={() => setProductQuery("")}><X size={16}/></button>}</label><span>{visibleProducts.length} modèles</span></div>
        <div className="ast-product-grid">
          <article className="ast-product-card ast-free-product">
            <div className="ast-product-visual mint"><div className="ast-product-window"><div className="ast-window-top"><span/><span/><span/><i>ASTULINK · EXCEL</i></div><div className="ast-window-content"><div className="ast-window-title"/><div className="ast-window-subtitle"/><div className="ast-window-cells"><i/><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="ast-window-bottom"><span/><span/><span/></div></div></div><span className="ast-product-icon"><Wallet size={19}/></span></div>
            <div className="ast-product-info"><span className="ast-product-tag">GRATUIT · FICHIER EXCEL</span><h3>Mini-budget mensuel</h3><p>Suivez vos revenus, vos dépenses et votre solde disponible avec un tableau simple et automatique.</p><div className="ast-product-foot"><a className="ast-free-download" href="/downloads/astulink-mini-budget.xlsx" download>{copy.free} <ArrowDown size={15}/></a><span className="ast-product-arrow"><ArrowUpRight size={17}/></span></div></div>
          </article>
          {displayedProducts.map((product) => { const Icon = product.icon; return <article className="ast-product-card" key={product.name}>
            <div className={`ast-product-visual ${product.color}`}><div className="ast-product-window"><div className="ast-window-top"><span/><span/><span/><i>{product.category}</i></div><div className="ast-window-content"><div className="ast-window-title"/><div className="ast-window-subtitle"/><div className="ast-window-cells"><i/><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="ast-window-bottom"><span/><span/><span/></div></div></div><span className="ast-product-icon"><Icon size={19}/></span></div>
            <div className="ast-product-info"><span className="ast-product-tag">{product.tag}</span><h3>{product.name}</h3><p>{product.description}</p><div className="ast-product-foot"><span className="ast-coming">Maquette · {product.price} indicatif</span><span className="ast-product-arrow"><ArrowUpRight size={17}/></span></div></div>
          </article>; })}
        </div>
        {visibleProducts.length === 0 && <p className="ast-no-products">Aucun modèle ne correspond à votre recherche. Essayez un autre terme ou choisissez une catégorie dans le menu.</p>}
        {visibleProducts.length > 6 && <button className="ast-view-all" onClick={() => setShowAllProducts(!showAllProducts)}>{showAllProducts ? "Réduire la sélection" : `Voir les ${visibleProducts.length} modèles`} <ArrowRight size={16}/></button>}
      </section>

      <section className="ast-how" id="fonctionnement">
        <div className="ast-how-intro"><div className="ast-eyebrow">PAS BESOIN D'ÊTRE EXPERT</div><h2>{copy.how}<br/><em>{copy.how2}</em></h2><p>Des outils conçus pour être utiles dès la première ouverture, sans logiciel compliqué ni abonnement récurrent.</p><a href="#selection" className="ast-button ast-button-light">{copy.find} <ArrowRight size={17}/></a></div>
        <div className="ast-steps"><div className="ast-step"><span>01</span><div><b>Choisissez votre besoin</b><p>Parcourez les catégories et repérez le fichier adapté à votre situation.</p></div><FileSpreadsheet size={22}/></div><div className="ast-step"><span>02</span><div><b>Téléchargez votre fichier</b><p>Récupérez votre modèle numérique après votre achat.</p></div><ArrowDown size={22}/></div><div className="ast-step"><span>03</span><div><b>Personnalisez et utilisez</b><p>Renseignez vos informations et laissez les formules faire le travail.</p></div><Check size={22}/></div></div>
      </section>

      <section className="ast-bottom-cta"><div className="ast-cta-spark">✳</div><div><div className="ast-eyebrow">ASTULINK · L'UTILE EN UN CLIC</div><h2>Et si c'était<br/><em>plus simple ?</em></h2></div><a href="#selection" className="ast-button ast-button-dark">Explorer les catégories <ArrowUpRight size={17}/></a></section>

      <footer className="ast-footer"><div className="ast-footer-main"><Logo/><p>Des outils numériques pratiques pour mieux organiser vos projets, vos activités et votre quotidien.</p><a href="#accueil" className="ast-back-top">Retour en haut ↑</a></div><div className="ast-footer-bottom"><span>© {new Date().getFullYear()} Astulink. Tous droits réservés.</span><span>Une boutique de fichiers numériques en préparation.</span></div></footer>
    </main>
  );
}
