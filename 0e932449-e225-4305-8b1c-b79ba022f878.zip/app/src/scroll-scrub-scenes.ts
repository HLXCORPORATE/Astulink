/**
 * Scroll-scrub scene data is intentionally empty for the first Astulink release.
 * The storefront uses lightweight CSS motion instead of generated video assets,
 * keeping the launch independent from paid media credits.
 */
import type {
  ScrollScrubScene,
  ScrollScrubTheme,
} from "@/components/scroll-scrub/scroll-scrub";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#789a70",
  background: "#f5f4ee",
  ink: "#1c2b25",
  muted: "#68756d",
};

export const scrollScrubScenes: ScrollScrubScene[] = [];
